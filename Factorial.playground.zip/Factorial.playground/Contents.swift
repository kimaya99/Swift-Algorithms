// Factorial
// Uint - non negative value

func factorial (value: UInt) -> UInt {
    var product :UInt = 1
    
    if value == 0 {
        return 1
    }
    for i in 1...value {
        product = product * i
    }
    return product
}
print(factorial(value: 4))

func factorialWithRecursion (value: UInt) -> UInt {
    var product : UInt = 1
    
    if value == 0 {
        return 1
    }
    
    return value * factorialWithRecursion(value: value - 1)
}

print(factorialWithRecursion(value: 4))
